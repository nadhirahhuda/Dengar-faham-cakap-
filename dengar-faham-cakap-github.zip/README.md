# Dengar, Faham & Cakap! 🎧

Permainan interaktif Bahasa Melayu dengan lima soalan, pilihan gambar, markah dan rakaman suara guru.

## Terbitkan di GitHub Pages

1. Cipta repositori baharu di GitHub.
2. Muat naik fail `index.html` ke direktori utama repositori.
3. Pergi ke **Settings → Pages**.
4. Pilih **Deploy from a branch**, kemudian **main** dan **/(root)**, lalu klik **Save**.
5. Selepas laman diterbitkan, buka URL GitHub Pages yang dipaparkan.

## Penggunaan

Masukkan nama murid, kelas dan tarikh. Bagi setiap soalan, pilih rakaman MP3 daripada peranti, tekan **Dengar rakaman** (maksimum dua kali), kemudian pilih jawapan.

**Nota:** Rakaman MP3 tidak disertakan dalam repositori. Guru perlu menyediakan rakaman sendiri. Fail dipilih secara setempat melalui pelayar dan tidak dihantar ke pelayan. Fon, Tailwind CSS dan ikon Lucide menggunakan CDN; sambungan internet diperlukan untuk gaya/ikon tersebut.
